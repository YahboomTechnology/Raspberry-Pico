/**
 * \defgroup pico_util pico_util
 * \brief Useful data structures and utility functions
 */
