Note: most of these examples are copies of the tinyusb examples in pico-sdk/lib/tinyusb/examples
