#include <stdio.h>
#include "pico/stdlib.h"


int main()
{
    const uint LED_PIN = 15;
	const uint KEY_PIN = 14;
	
    gpio_init(LED_PIN);
	gpio_init(KEY_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    gpio_set_dir(KEY_PIN, GPIO_IN);
	
    while (true) {
		if(gpio_get(KEY_PIN) == 1)
		{
          gpio_put(LED_PIN, 1);
          sleep_ms(2000);			
		}
		  gpio_put(LED_PIN, 0);
    }

}
