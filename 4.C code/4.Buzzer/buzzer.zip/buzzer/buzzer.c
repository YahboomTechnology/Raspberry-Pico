#include <stdio.h>
#include "pico/stdlib.h"


int main()
{
    const uint BUZZER_PIN = 15;
	
    gpio_init(BUZZER_PIN);
    gpio_set_dir(BUZZER_PIN, GPIO_OUT);
	
    while (1) {
		for(int i = 0;i<80;i++)
		{
          gpio_put(BUZZER_PIN, 1);
          sleep_ms(1);			
          gpio_put(BUZZER_PIN, 0);
          sleep_ms(1);			
		}
		for(int i = 0;i<100;i++)
		{
          gpio_put(BUZZER_PIN, 1);
          sleep_ms(2);			
          gpio_put(BUZZER_PIN, 0);
          sleep_ms(2);						
		}

    }

}
