#include "pico/stdlib.h"
#include "hardware/pwm.h"

int main() {



    gpio_set_function(15, GPIO_FUNC_PWM);


    uint slice_num = pwm_gpio_to_slice_num(15);


    pwm_set_wrap(slice_num, 255);

    pwm_set_chan_level(slice_num, PWM_CHAN_B, 0);
    // Set the PWM running
    pwm_set_enabled(slice_num, true);
	
	while(1)
	{
		for(int i = 0;i <= 255;i++)
		{
			pwm_set_chan_level(slice_num, PWM_CHAN_B, i);
			sleep_ms(50);
		}
		for(int i = 255;i >= 0;i--)
		{
			pwm_set_chan_level(slice_num, PWM_CHAN_B, i);
			sleep_ms(50);
		}
			
		
	}
	

}
